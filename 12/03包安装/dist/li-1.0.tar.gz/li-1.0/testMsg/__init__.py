__all__ = ['sendMsg']

from . import sendMsg