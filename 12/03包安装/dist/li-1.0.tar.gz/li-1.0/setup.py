from distutils.core import setup

setup(name="li", version="1.0", description="module",
      author="li", py_modules=["testMsg.sendMsg","testMsg.recvmsg"])
